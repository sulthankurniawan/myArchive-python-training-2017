import json

#Ini adalah fungsi untuk memasukkan atau minta input
'''
	ini adalah komentar dengan 
	multiline
'''

# name = "febrian"
# var = input('variable: ')
# print var

# name = raw_input("masukkan nama anda: ")
# print "Hello", name

### pendeklarasian tipe data ###
namadepan= "Febrian Imanda"
namabelakang = "effendy"
angkastr = "123"
angka = 123
angkadesimal = 13.0
boolean = True
# print type(namadepan)
# print type(angka)
# print type(angkadesimal)
# print type(boolean)
# print angkastr, type(angkastr)
# print int(angkastr), type(int(angkastr))
# print float(angkastr), type(float(angkastr))
# print "Hallo " + namadepan + " "+ namabelakang + `angka`


### conditional ###
# ak = 100
# if ak < 10:
# 	print "dibawah 10"
# 	print True
# else:
# 	print False
# 	if ak < 50:
# 		print "masih dibawah 50"
# 	elif ak <= 100: #elseif
# 		print "ini angka 100"
# 	else:
# 		print "ulululu ini sepertinya ada eror"

## short hand conditional ##
# print "ini 100" if ak == 100 else "bukan 100"
# # hasilout = (ak == 100) ? "ini 100" : "bukan 100" #di Java
# hasilout = "bukan 100" if ak != 100 else "ini 100"
# print hasilout


### loop ###
i = 0
berhenti = False
# while not berhenti:
# 	if i > 10:
# 		# berhenti = True
# 		break
# 	else:
# 		i += 1
# 		print i

# for var range([start,] stop [,step])
# for i in range(1, 10):
# 	if i > 5:
# 		break
# 	print i,

### List ###
# arr = [1,'febrian',3,'imanda',5,6,7]
# dicari = "febrian"
# print arr

##conditional dalam list
# if dicari in arr:
# 	print True
# else:
# 	print False

## loop dalam list 
# for i in arr:
# 	print i

##loop dalam list dengan index
# print "panjangnya adalah: ",len(arr)
# for i in range(len(arr)):
# 	print "index %d %s %s" % (i, arr[i], type(arr[i]))

# arr2 = []
arr3 = [9,11,17,2,5]
# print arr3
# arr3.reverse()
# print arr3
# arr3.sort()
# print arr3
# arr3.sort(reverse=True)
# print arr3
# arr4 = [4,6,7]
# for i in range(0, 20,3):
# 	arr2.append(i)

# print "arr2:",arr2
# arr2.extend(arr3)
#pass by reference
# arr6 = arr2 
#pass by value
# arr5 = arr2[:] 
# arr5.sort(reverse=True)

# print "arr2:",arr2
# print "arr6:",arr6
# arr6.append(123)
# print "arr6:",arr6
# print "arr5:",arr5
# arr2.append(arr4)
# print "arr2:", arr2

## deklarasi list shorthand
# arr7 = [x for x in range(10)]
# print "arr7:",arr7

## Slicing dalam list
# arr = ['febrian', 'imanda', 'effendy']
# print arr[0], arr[1]
# print arr[0:2]

# name = "febrian imanda"
# print name[:8]
# print name[8:]
# for i in name:
# 	print i,

### Dictionaries
## deklarasi dictionary
# mahasiswa = {
# 	'nama': "febrian",
# 	'angkatan': '2013',
# 	"jurusan": 'S1 Teknik Informatika'
# }

# mahasiswa2 = {
# 	'nama': 'iqbal'
# }

# mahasiswa3 = ["febrian", 2013, "S1 Teknik Informatika"]
# print mahasiswa3[0]

# print mahasiswa
# print mahasiswa['nama'], mahasiswa['angkatan']
# print mahasiswa2
# mahasiswa2['angkatan'] = 2014 #assign value
# print mahasiswa2['nama'], mahasiswa2['angkatan']

## list of dictionaries
listMahasiswa = []
listNama = ['febrian', 'iqbal', 'nanon', 'ridhwan', 'hilmi']
for i in range(5):
	obj = {
		'index': i,
		'nama': listNama[i],
		'angkatan': 2013 if listNama[i] == 'febrian' else 2014,
		'jurusan': "S1 Teknik Informatika"
	}
	listMahasiswa.append(obj)

## access list of dictionarie
# for mahasiswa in listMahasiswa:
# 	print mahasiswa

### File I/O
## save File
def saveFile(namafile, data, printOut=True):
	f = open(namafile,'w')
	for line in data:
		print >> f, data
	f.close()
	if printOut:
		print "file %s disimpan" % namafile

def saveJsonFile(namafile, data):
	file = open(namafile, 'w')
	for mahasiswa in data:
		json.dump(mahasiswa, file)
	file.close()
	print "File %s disimpan" % namafile

## Load File
def loadData(namafile):
	f = open(namafile,'r')
	print "file",namafile,"berhasil di load"
	data = [line for line in f]
	return data

# saveFile('data6.txt',listMahasiswa, printOut=False)
print loadData('data2.txt')


### class / object
# class Fruit(object):

# 	def __init__(self, nama, warna, rasa, beracun, tglKadaluarsa):
# 		self.nama = nama
# 		self.warna = warna
# 		self.rasa = rasa
# 		self.beracun = beracun
# 		self.tglKadaluarsa = tglKadaluarsa

# 	def bolehDimakan(self):
# 		if self.beracun == True:
# 			print "Buah %s Tidak boleh dimakan" % self.nama
# 		else:
# 			print "Buah %s boleh dimakan" % self.nama

# 	def membusuk(self):
# 		self.beracun = True

# 	def cekKadaluarsa(self, tglSekarang):
# 		if tglSekarang > self.tglKadaluarsa:
# 			self.membusuk()
# 			print "Sudah membusuk"
# 		else:
# 			print "Masih baik"

# apple = Fruit("apel", "merah", "manis", False, 20)
# print apple.beracun
# apple.cekKadaluarsa(22)
# print apple.beracun
# apple.bolehDimakan()