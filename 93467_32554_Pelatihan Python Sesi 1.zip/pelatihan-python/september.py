## Input Output

# print "Hello World"

# name = raw_input("Masukkan Nama Anda: ")
# print name

# name = "Febrian"
# var = input("Variable yang ingin ditampilkan: ")
# print var


## Variable
# text = "ini adalah variable string"
# text2 = "digabung string 2"
# angka = 1123123
# truefalse = True
# desimal = 11.5

# print text + `angka`

# print text, angka, truefalse, desimal

# print isinstance(text, str)
# print isinstance(angka, int)
# print isinstance(truefalse, bool)
# print isinstance(desimal, float)

## Conditional If Else
# angka = 50
# if angka < 70 :
# 	print True
# 	print "ini adalah indentasi berbeda 1"
# 	if not isinstance(angka, str):
# 		print "Ye dia integer"
# 	else:
# 		print "Ye dia string"
# else:
# 	print False
# 	print "ini adalah indentasi berbeda 2"

# angka = 100
# angkaku1 = "genap" if (angka % 2 == 0) else "ganjil"
# print angkaku1

# print "genap" if (angka % 2 == 0) else "ganjil"

## For Loop

# for i in range(10, 100, 5):
# 	print i,

# ketemu = False
# i = 0
# x = 80
# while not ketemu:
# 	print i,
# 	if i == x:
# 		# ketemu = True
# 		break
# 	i += 5

## LIST

# arr = [23,51,5,7,21,43]
# print isinstance(arr, list)
# print arr

# print sorted(arr, reverse=True)
# print len(arr)

# for i in arr:
# 	print i,

# print ''

# name = "Telkom University"
# for i in name:
# 	if i == ' ':
# 		break
# 	else:
# 		print i,

# print name[3:10]

# arr = [23,51,5,7,21,43]
# print arr
# # arr3 = arr[0:3] + [20] + arr[3:7]
# # print arr3
# arr.append(20)
# print arr
# del arr[5]
# print arr
# arr2 = [10, 2, 12]
# arr.extend(arr2)
# print arr
# print arr[6]

# print 23 in arr
# if 23 in arr:
# 	print True
# else:
# 	print False

# arr = [23,51,5,7,21,43]
# print arr[0]

# mahasiswa1 = {
# 	'name': 'Febrian Imanda',
# 	'angkatan': '2013'
# }

# mahasiswa2 = {
# 	'name': 'John Doe',
# 	'angkatan': '2012'
# }

# mahasiswa2['lulus'] = True

# dataMahasiswa = [mahasiswa1, mahasiswa2]

# for i in dataMahasiswa:
# 	print i
# 	print i['name'], ' - ', i['angkatan']

# print mahasiswa
# print mahasiswa['name']

## function

#void function
def perkalian(angka1, angka2):
	hasil = angka1 * angka2
	print hasil

hasil = perkalian(10, 12)
print hasil #hasil none karena tidak ada return atau nilai balik

tuple1 = (1,2,3)
print tuple1
# tuple1[0] = 5 # ini akan error karena tuple tidak boleh diubah nilainya